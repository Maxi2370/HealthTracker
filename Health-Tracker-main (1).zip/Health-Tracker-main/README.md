# Health-Tracker
The app was created by Sarah Stein, Max van de Ven and Pauline Schudrowitsch as part of the Introduction to Programming (S2) class.
